import streamlit as st, joblib
model = joblib.load('pipeline.joblib')
st.title("Review Sentiment")
txt = st.text_area('Paste review')
if st.button('predict'):
    pred = model.predict([txt])[0]
    st.write('Sentiment:',pred)
